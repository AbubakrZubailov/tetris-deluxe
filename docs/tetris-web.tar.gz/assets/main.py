"""Browser entry point for Tetris Deluxe."""
import asyncio
import json
import platform

import pygame

import tetris
import tetris_core

read_file = tetris_core._dict_from


def storage_key(path):
    return f'Tetris Deluxe:{str(platform.window.location.pathname).rstrip("/")}:{path.name}'


def read_browser_file(path):
    try:
        value = json.loads(str(platform.window.localStorage.getItem(storage_key(path))))
        if isinstance(value, dict):
            return value
    except Exception:
        pass
    return read_file(path)


class BrowserStore(tetris_core.Store):
    def _save(self, path, value):
        try:
            platform.window.localStorage.setItem(storage_key(path), json.dumps(value))
            return True
        except Exception:
            return super()._save(path, value)


tetris_core._dict_from = read_browser_file
tetris.Store = BrowserStore


class BrowserApp(tetris.DeluxeApp):
    def set_fullscreen(self, enabled):
        if self.window is None:
            enabled = False  # The browser requires a fresh user gesture.
            self.windowed_size = (tetris.W, tetris.H)
            self.window = pygame.display.set_mode(self.windowed_size)
        document = platform.window.document
        if enabled and not document.fullscreenElement:
            document.documentElement.requestFullscreen().catch(lambda error: None)
        elif not enabled and document.fullscreenElement:
            document.exitFullscreen().catch(lambda error: None)
        self.fullscreen = enabled
        self.settings['fullscreen'] = enabled

    def quit(self):
        if self.state in ('playing', 'paused', 'settings') and self.game:
            self.abandon()
        else:
            self.go('menu')
        self.store.save_settings()

    async def run_browser(self):
        last = pygame.time.get_ticks()
        while self.running:
            now = pygame.time.get_ticks()
            dt = min(.06, (now - last) / 1000)
            last = now
            self.elapsed_ui += dt
            self.handle_events()
            self.fullscreen = bool(platform.window.document.fullscreenElement)
            self.settings['fullscreen'] = self.fullscreen
            if self.state == 'playing':
                self.update_game(dt)
            self.update_particles(dt)
            self.sound.update(self.settings)
            self.render()
            await asyncio.sleep(0)


async def main():
    await BrowserApp().run_browser()


asyncio.run(main())
